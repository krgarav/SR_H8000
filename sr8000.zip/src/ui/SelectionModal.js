import React from 'react'

const SelectionModal = () => {
    return (
        <div>SelectionModal</div>
    )
}

export default SelectionModal;